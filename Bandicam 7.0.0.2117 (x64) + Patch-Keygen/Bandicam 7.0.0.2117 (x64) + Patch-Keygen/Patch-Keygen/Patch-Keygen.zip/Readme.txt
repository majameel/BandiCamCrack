1. Remove the previously installed version using special software Revo Uninstaller or others.
2. Run "BC Reset.exe" as Admin.
3. Copy "msimg32.dll" to program folder, then run keygen to register program.

Also add to hosts file:
0.0.0.0 www.bandicam.com
0.0.0.0 bandicam.com
0.0.0.0 www.bandisoft.com
0.0.0.0 bandisoft.com
0.0.0.0 cert.bandicam.com
0.0.0.0 ssl.bandisoft.com

Note: Run the BC Reset couple of times, till the app is activated